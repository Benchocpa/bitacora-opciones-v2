import ErrorBoundary from "./ErrorBoundary"
import KPICards from "@/components/KPICards"

const kpis = {
  sumaPrimas: 0,
  totalCostos: 0,
  gananciaNeta: 0,
  roiGeneral: 0,
  total: 0,
  capitalInvertido: 0,
}

export default function App() {
  return (
    <ErrorBoundary>
      <div className="p-4 space-y-4">
        <h1 className="text-xl font-semibold">Bitácora de Opciones V2</h1>
        <KPICards kpis={kpis} />
      </div>
    </ErrorBoundary>
  )
}
